import React from 'react';

const Login = () => {
  return (
    <div>
      <form > 
      
      </form>
    </div>
  );
}

export default Login;
