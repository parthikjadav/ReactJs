import React from "react";
import { useState } from "react";
import { useRef } from "react";
import Form from "./comp/Form";

const App = () => {
  return <>
      <Form />
    </>

};

export default App;
